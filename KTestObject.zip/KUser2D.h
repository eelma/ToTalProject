#pragma once
#include"KObject2D.h"
class KUser2D :public KObject2D
{

public:
	bool Frame()override;
};